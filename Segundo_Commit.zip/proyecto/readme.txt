Hola profe, somos Henry Carreño y Cristian Becerra, bienvenido a nuestro repositorio de GitHub, este es nuestro parcial hecho en parejas, aca encontrara todo el código fuente de nuestra pagina web (login, paginas de aterrizaje, css, HTML, etc...).

Espero sea de su agrado y esperamos buena nota. C: